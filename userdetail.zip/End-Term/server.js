const express = require('express');
const app = express();
const session = require('express-session');
const cookie = require('cookie-parser');
const multer = require('multer');
const mongodb = require('mongodb');
const ObjectId = mongodb.ObjectId;
const client = mongodb.MongoClient;
let dbInstance;

client.connect('mongodb+srv://Shubham:4321@database.jzu6gw9.mongodb.net/?retryWrites=true&w=majority&appName=DataBase').then(database=>{
    dbInstance = database.db('new-db');
    if(dbInstance){
        console.log('MongoDB connected successfully');
    }
}).catch(err=>{
    console.log(err);
})

app.set('view engine','ejs');
app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.use(session({
    saveUninitialized: true,
    resave: false,
    secret: 'sexret-key',
    cookie: {
        maxAge: 1000*60*60*24,
    }
}))
app.use(cookie());

app.get(['/','/login'],(req,res)=>{
    res.render('login');
})
app.get('/signup',(req,res)=>{
    res.render('signup');
})
app.get('/dashboard',(req,res)=>{
    dbInstance.collection('users').find().toArray().then((data)=>{
        res.render('index',{users: data});
    })
})
app.get('/update-user/:id',(req,res)=>{
    res.render('update',{id: req.params.id});
})

app.post('/login',(req,res)=>{
    dbInstance.collection('users').find(req.body).toArray().then((data)=>{
        if(data.length > 0){
            req.session.user = data[0];
            res.redirect('/dashboard');
        }else{
            res.redirect('/signup');
        }
    }).catch((err)=>{
        console.error(err);
    })
})

app.post('/signup',(req,res)=>{
    dbInstance.collection('users').find(req.body).toArray().then((data)=>{
        if(data.length == 0){
            dbInstance.collection('users').insertOne(req.body).then(()=>{
                res.redirect('/login');
            }).catch((err)=>{
                console.error(err);
            })
        }else{
            res.redirect('/login');
        }
    }).catch((er)=>{
        console.error(err);
    })
})

app.delete('/delete-user/:id',(req,res)=>{
    const id = req.params.id;
    dbInstance.collection('users').deleteOne({_id : new ObjectId(id)}).then(()=>{
        res.send();
    }).catch((err)=>{
        console.error(err);
    })
})

app.put('/update-user/:id',(req,res)=>{
    const id = req.params.id;
    const {username} = req.body;
    console.log(req.body);
    dbInstance.collection('users').updateOne({_id : new ObjectId(id)},{$set: {username: username}}).then(()=>{
        res.send();
    }).catch((err)=>{
        console.error(err);
    })
})

app.listen(3000,(err)=>{
    if(err){
        console.log(err);
    }else{
        console.log('Server started on port 3000');
    }
})